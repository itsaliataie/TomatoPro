package com.example.tomatopro.data

/**
 * Enumerates the different types of timers. A focus session is a work period, followed
 * by either a short break or a long break after a number of focus cycles. The Idle state
 * represents no active timer.
 */
enum class TimerType {
    Focus,
    ShortBreak,
    LongBreak,
    Idle
}