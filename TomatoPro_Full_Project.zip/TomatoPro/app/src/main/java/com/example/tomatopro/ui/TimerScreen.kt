package com.example.tomatopro.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tomatopro.MainViewModel
import com.example.tomatopro.data.TimerType
import kotlinx.coroutines.flow.collect

@Composable
fun TimerScreen(viewModel: MainViewModel) {
    val timerType by viewModel.timerType.collectAsState()
    val remainingSeconds by viewModel.remainingSeconds.collectAsState()
    val isRunning by viewModel.isRunning.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = when (timerType) {
                TimerType.Focus -> "Focus Session"
                TimerType.ShortBreak -> "Short Break"
                TimerType.LongBreak -> "Long Break"
                TimerType.Idle -> "Ready"
            },
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(32.dp))
        Text(
            text = formatTime(remainingSeconds),
            style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(32.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isRunning) {
                Button(onClick = { viewModel.pauseTimer() }) {
                    Text("Pause")
                }
            } else {
                Button(onClick = { viewModel.startTimer() }) {
                    Text(if (timerType == TimerType.Idle) "Start" else "Resume")
                }
            }
            Button(onClick = { viewModel.resetTimer() }, colors = ButtonDefaults.buttonColors()) {
                Text("Reset")
            }
        }
        if (timerType != TimerType.Focus && timerType != TimerType.Idle) {
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { viewModel.skipBreak() }) {
                Text("Skip Break")
            }
        }
    }
}

@Composable
private fun formatTime(seconds: Long): String {
    val minutesPart = seconds / 60
    val secondsPart = seconds % 60
    return String.format("%02d:%02d", minutesPart, secondsPart)
}