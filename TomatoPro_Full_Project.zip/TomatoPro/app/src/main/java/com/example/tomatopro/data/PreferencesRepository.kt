package com.example.tomatopro.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private const val DATASTORE_NAME = "tomato_prefs"

/**
 * Extension property on Context to create a DataStore instance. We use Preferences DataStore
 * to persist user-configurable timer durations and the number of focus sessions before a long break.
 */
val Context.dataStore by preferencesDataStore(name = DATASTORE_NAME)

class PreferencesRepository(private val context: Context) {

    private object PreferenceKeys {
        val focusDurationMinutes = intPreferencesKey("focus_duration_minutes")
        val shortBreakMinutes = intPreferencesKey("short_break_minutes")
        val longBreakMinutes = intPreferencesKey("long_break_minutes")
        val cyclesBeforeLongBreak = intPreferencesKey("cycles_before_long_break")
    }

    /**
     * A flow that emits the current timer settings whenever they change. Default values are used
     * when preferences haven't been set yet.
     */
    val settingsFlow: Flow<TimerSettings> = context.dataStore.data
        .map { prefs ->
            TimerSettings(
                focusMinutes = prefs[PreferenceKeys.focusDurationMinutes] ?: 25,
                shortBreakMinutes = prefs[PreferenceKeys.shortBreakMinutes] ?: 5,
                longBreakMinutes = prefs[PreferenceKeys.longBreakMinutes] ?: 15,
                cyclesBeforeLongBreak = prefs[PreferenceKeys.cyclesBeforeLongBreak] ?: 4
            )
        }

    suspend fun updateFocusMinutes(minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.focusDurationMinutes] = minutes
        }
    }

    suspend fun updateShortBreakMinutes(minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.shortBreakMinutes] = minutes
        }
    }

    suspend fun updateLongBreakMinutes(minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.longBreakMinutes] = minutes
        }
    }

    suspend fun updateCyclesBeforeLongBreak(cycles: Int) {
        context.dataStore.edit { prefs ->
            prefs[PreferenceKeys.cyclesBeforeLongBreak] = cycles
        }
    }
}

/**
 * Data class to hold timer configuration values.
 */
data class TimerSettings(
    val focusMinutes: Int,
    val shortBreakMinutes: Int,
    val longBreakMinutes: Int,
    val cyclesBeforeLongBreak: Int
)