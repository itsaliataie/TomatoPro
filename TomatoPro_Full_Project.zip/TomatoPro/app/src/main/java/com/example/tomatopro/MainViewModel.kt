package com.example.tomatopro

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.tomatopro.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * The MainViewModel encapsulates the timer logic, session persistence, and settings management. It
 * exposes flows of timer state and statistics which the UI observes and renders.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val preferencesRepository = PreferencesRepository(application)
    private val database = AppDatabase.getDatabase(application)
    private val sessionDao = database.sessionDao()

    // Expose settings as a StateFlow so UI can collect the latest timer configuration
    val settings: StateFlow<TimerSettings> = preferencesRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = TimerSettings(25, 5, 15, 4)
    )

    // Timer state
    private val _timerType = MutableStateFlow(TimerType.Idle)
    val timerType: StateFlow<TimerType> = _timerType.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(0L)
    val remainingSeconds: StateFlow<Long> = _remainingSeconds.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private var currentCycle = 0
    private var countdownJob: Job? = null
    private var currentStartTime: Long = 0L

    // Statistics: minutes accumulated today, this week, this month; plus daily totals for last 52 weeks
    data class Stats(
        val todayMinutes: Int,
        val weekMinutes: Int,
        val monthMinutes: Int,
        val dailyMinutes: Map<LocalDate, Int>
    )

    val statsFlow: StateFlow<Stats> = sessionDao.getAllSessions()
        .map { sessions -> computeStats(sessions) }
        .stateIn(
            viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = Stats(0, 0, 0, emptyMap())
        )

    /** Starts or resumes the timer. If the timer is Idle, a focus session is started. */
    fun startTimer() {
        val currentSettings = settings.value
        if (_timerType.value == TimerType.Idle) {
            _timerType.value = TimerType.Focus
            _remainingSeconds.value = currentSettings.focusMinutes * 60L
            currentCycle = 0
            currentStartTime = System.currentTimeMillis()
        }
        _isRunning.value = true
        if (countdownJob == null || countdownJob?.isCompleted == true) {
            countdownJob = viewModelScope.launch(Dispatchers.Default) {
                while (_isRunning.value && _remainingSeconds.value > 0) {
                    delay(1000L)
                    if (!_isRunning.value) break
                    _remainingSeconds.update { it - 1 }
                }
                if (_isRunning.value && _remainingSeconds.value == 0L) {
                    onTimerFinished()
                }
            }
        }
    }

    /** Pauses the current timer. */
    fun pauseTimer() {
        _isRunning.value = false
    }

    /** Resets the timer to Idle state and clears cycles and remaining time. */
    fun resetTimer() {
        _isRunning.value = false
        _timerType.value = TimerType.Idle
        _remainingSeconds.value = 0L
        currentCycle = 0
        countdownJob?.cancel()
        countdownJob = null
    }

    /** Skips the current break and immediately starts a new focus session. */
    fun skipBreak() {
        val currentSettings = settings.value
        _timerType.value = TimerType.Focus
        _remainingSeconds.value = currentSettings.focusMinutes * 60L
        currentStartTime = System.currentTimeMillis()
        _isRunning.value = false
    }

    /** Called when a timer counts down to zero. Records a session and determines the next timer type. */
    private fun onTimerFinished() {
        // Insert session into database
        val endTime = System.currentTimeMillis()
        val type = _timerType.value
        if (type != TimerType.Idle) {
            viewModelScope.launch(Dispatchers.IO) {
                sessionDao.insert(Session(
                    startTime = currentStartTime,
                    endTime = endTime,
                    type = type.name
                ))
            }
        }
        val currentSettings = settings.value
        when (type) {
            TimerType.Focus -> {
                currentCycle++
                if (currentCycle % currentSettings.cyclesBeforeLongBreak == 0) {
                    _timerType.value = TimerType.LongBreak
                    _remainingSeconds.value = currentSettings.longBreakMinutes * 60L
                } else {
                    _timerType.value = TimerType.ShortBreak
                    _remainingSeconds.value = currentSettings.shortBreakMinutes * 60L
                }
                currentStartTime = System.currentTimeMillis()
                // automatically start break
                _isRunning.value = true
                startTimer()
            }
            TimerType.ShortBreak, TimerType.LongBreak -> {
                _timerType.value = TimerType.Focus
                _remainingSeconds.value = currentSettings.focusMinutes * 60L
                currentStartTime = System.currentTimeMillis()
                // automatically start next focus session
                _isRunning.value = true
                startTimer()
            }
            TimerType.Idle -> {
                // Should not happen
                resetTimer()
            }
        }
    }

    /**
     * Computes statistics from the list of sessions. Returns total minutes for today,
     * this week, this month, and a map of minutes per day for the last 52 weeks.
     */
    private fun computeStats(sessions: List<Session>): Stats {
        val zone = ZoneId.systemDefault()
        val nowDate = LocalDate.now(zone)
        val startOfToday = nowDate.atStartOfDay(zone).toInstant().toEpochMilli()
        val startOfWeek = nowDate.with(java.time.DayOfWeek.MONDAY).atStartOfDay(zone).toInstant().toEpochMilli()
        val startOfMonth = nowDate.withDayOfMonth(1).atStartOfDay(zone).toInstant().toEpochMilli()

        var todayMinutes = 0
        var weekMinutes = 0
        var monthMinutes = 0
        // For heatmap: track minutes per day for last 52 weeks
        val dailyMinutes: MutableMap<LocalDate, Int> = mutableMapOf()

        for (session in sessions) {
            val startInstant = Instant.ofEpochMilli(session.startTime)
            val endInstant = Instant.ofEpochMilli(session.endTime)
            val minutes = ChronoUnit.MINUTES.between(startInstant, endInstant).toInt()
            val sessionDate = startInstant.atZone(zone).toLocalDate()

            if (session.startTime >= startOfToday) {
                todayMinutes += minutes
            }
            if (session.startTime >= startOfWeek) {
                weekMinutes += minutes
            }
            if (session.startTime >= startOfMonth) {
                monthMinutes += minutes
            }
            if (!dailyMinutes.containsKey(sessionDate)) {
                dailyMinutes[sessionDate] = minutes
            } else {
                dailyMinutes[sessionDate] = dailyMinutes[sessionDate]!! + minutes
            }
        }

        // Retain only last 52 weeks of data
        val cutoffDate = nowDate.minusWeeks(52)
        val filtered = dailyMinutes.filter { it.key >= cutoffDate }

        return Stats(todayMinutes, weekMinutes, monthMinutes, filtered)
    }

    // Settings update convenience functions
    fun updateFocusMinutes(minutes: Int) {
        viewModelScope.launch { preferencesRepository.updateFocusMinutes(minutes) }
    }

    fun updateShortBreakMinutes(minutes: Int) {
        viewModelScope.launch { preferencesRepository.updateShortBreakMinutes(minutes) }
    }

    fun updateLongBreakMinutes(minutes: Int) {
        viewModelScope.launch { preferencesRepository.updateLongBreakMinutes(minutes) }
    }

    fun updateCyclesBeforeLongBreak(cycles: Int) {
        viewModelScope.launch { preferencesRepository.updateCyclesBeforeLongBreak(cycles) }
    }
}