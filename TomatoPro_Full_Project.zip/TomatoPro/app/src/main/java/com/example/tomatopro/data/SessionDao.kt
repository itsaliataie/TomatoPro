package com.example.tomatopro.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    /**
     * Inserts a new session into the database.
     *
     * Returning the row ID of the newly inserted session avoids a Room
     * annotation processor error where suspend functions returning Unit
     * generate a raw Object return type. See:
     * https://issuetracker.google.com/issues/220225666
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: Session): Long

    @Query("SELECT * FROM Session ORDER BY startTime DESC")
    fun getAllSessions(): Flow<List<Session>>

    @Query("SELECT * FROM Session WHERE startTime >= :startMs")
    fun getSessionsFrom(startMs: Long): Flow<List<Session>>
}