package com.example.tomatopro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.tomatopro.data.TimerType
import com.example.tomatopro.ui.HeatmapScreen
import com.example.tomatopro.ui.SettingsScreen
import com.example.tomatopro.ui.StatsScreen
import com.example.tomatopro.ui.TimerScreen
import com.example.tomatopro.ui.theme.TomatoProTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TomatoProTheme {
                // Get the view model
                val viewModel: MainViewModel = viewModel()
                MainScreen(viewModel)
            }
        }
    }
}

/**
 * Defines the routes and icon/label pairs for each tab in the bottom navigation bar.
 */
private enum class Screen(val label: String, val icon: ImageVector) {
    Timer("Timer", Icons.Default.Timer),
    Stats("Stats", Icons.Default.BarChart),
    Heatmap("Heatmap", Icons.Default.CalendarMonth),
    Settings("Settings", Icons.Default.Settings)
}

@Composable
private fun MainScreen(viewModel: MainViewModel) {
    var currentScreen by remember { mutableStateOf(Screen.Timer) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                Screen.values().forEach { screen ->
                    NavigationBarItem(
                        selected = currentScreen == screen,
                        onClick = { currentScreen = screen },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(Modifier.padding(innerPadding)) {
            when (currentScreen) {
                Screen.Timer -> TimerScreen(viewModel)
                Screen.Stats -> StatsScreen(viewModel)
                Screen.Heatmap -> HeatmapScreen(viewModel)
                Screen.Settings -> SettingsScreen(viewModel)
            }
        }
    }
}