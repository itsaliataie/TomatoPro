package com.example.tomatopro.data

/**
 * Represents a single focus or break session. We store the start and end timestamps
 * as epoch milliseconds and a string indicating the session type (focus, short break, long break).
 *
 * This data class no longer uses Room annotations since Room has been removed from the
 * project. Sessions will be persisted using a custom DataStore-based mechanism.
 */
data class Session(
    val startTime: Long,
    val endTime: Long,
    val type: String
)