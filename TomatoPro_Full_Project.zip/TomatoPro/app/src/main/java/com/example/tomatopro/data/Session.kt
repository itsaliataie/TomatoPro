package com.example.tomatopro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a single focus or break session. We store the start and end timestamps
 * as epoch milliseconds and a string indicating the session type (focus, short break, long break).
 */
@Entity
data class Session(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val startTime: Long,
    val endTime: Long,
    val type: String
)