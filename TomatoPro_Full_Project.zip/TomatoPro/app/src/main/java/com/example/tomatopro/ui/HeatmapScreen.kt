package com.example.tomatopro.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.tomatopro.MainViewModel
import java.time.LocalDate
import java.time.temporal.WeekFields
import kotlin.math.min

/**
 * Displays a GitHub-style heat map representing minutes of focus per day over the past year.
 */
@Composable
fun HeatmapScreen(viewModel: MainViewModel) {
    val stats by viewModel.statsFlow.collectAsState()
    val daily = stats.dailyMinutes
    val today = LocalDate.now()
    // Build a list of the last 52 weeks (each week is a column of 7 days)
    val weeks: MutableList<List<LocalDate>> = mutableListOf()
    var current = today
    // Determine the first day-of-week according to locale (Monday)
    val firstDayOfWeek = WeekFields.of(java.util.Locale.getDefault()).firstDayOfWeek
    // Walk backwards to the start of the current week
    while (current.dayOfWeek != firstDayOfWeek) {
        current = current.minusDays(1)
    }
    // Build 52 weeks
    for (w in 0 until 52) {
        val weekDays = mutableListOf<LocalDate>()
        var day = current.minusWeeks((51 - w).toLong())
        for (d in 0 until 7) {
            weekDays.add(day.plusDays(d.toLong()))
        }
        weeks.add(weekDays)
    }

    val scrollState = rememberScrollState()
    Row(
        modifier = Modifier
            .padding(16.dp)
            .horizontalScroll(scrollState),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        weeks.forEach { week ->
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                week.forEach { date ->
                    val minutes = daily[date] ?: 0
                    val intensity = computeIntensity(minutes)
                    val color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f + 0.6f * intensity)
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .background(color = color, shape = MaterialTheme.shapes.small)
                    )
                }
            }
        }
    }
}

/**
 * Maps minutes of focus to an intensity between 0 and 1. We cap at 120 minutes (~2 hours) for
 * maximum intensity. 0 minutes yields 0, 120 or more yields 1.
 */
private fun computeIntensity(minutes: Int): Float {
    val capped = min(minutes, 120)
    return capped / 120f
}