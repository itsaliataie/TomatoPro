package com.example.tomatopro.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.tomatopro.MainViewModel
import androidx.compose.runtime.collectAsState

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val settings by viewModel.settings.collectAsState()
    // Remember local states to edit numbers. Initialize when settings change.
    val focusState = remember(settings) { mutableStateOf(settings.focusMinutes.toString()) }
    val shortState = remember(settings) { mutableStateOf(settings.shortBreakMinutes.toString()) }
    val longState = remember(settings) { mutableStateOf(settings.longBreakMinutes.toString()) }
    val cyclesState = remember(settings) { mutableStateOf(settings.cyclesBeforeLongBreak.toString()) }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "Settings", style = MaterialTheme.typography.titleLarge)
        SettingRow(
            label = "Focus (min)",
            textState = focusState,
            onUpdate = { minutes -> viewModel.updateFocusMinutes(minutes) }
        )
        SettingRow(
            label = "Short Break (min)",
            textState = shortState,
            onUpdate = { minutes -> viewModel.updateShortBreakMinutes(minutes) }
        )
        SettingRow(
            label = "Long Break (min)",
            textState = longState,
            onUpdate = { minutes -> viewModel.updateLongBreakMinutes(minutes) }
        )
        SettingRow(
            label = "Cycles before Long Break",
            textState = cyclesState,
            onUpdate = { cycles -> viewModel.updateCyclesBeforeLongBreak(cycles) }
        )
    }
}

@Composable
private fun SettingRow(
    label: String,
    textState: androidx.compose.runtime.MutableState<String>,
    onUpdate: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = textState.value,
            onValueChange = { newValue ->
                // Accept only digits
                if (newValue.all { it.isDigit() }) {
                    textState.value = newValue
                }
            },
            label = { Text(label) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
        )
        Button(
            onClick = {
                val value = textState.value.toIntOrNull()
                if (value != null) {
                    onUpdate(value)
                }
            }
        ) {
            Text("Save")
        }
    }
}