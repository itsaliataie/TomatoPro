package com.example.tomatopro.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Extension property on Context to create a DataStore instance for session tracking.
 * We store a JSON serialized map of daily minutes keyed by ISO date (yyyy-MM-dd).
 */
val Context.sessionDataStore by preferencesDataStore(name = "session_data")

/**
 * Repository responsible for persisting and retrieving session statistics. Rather than using
 * Room, we store aggregated minutes per day in DataStore as a JSON map. Each entry
 * maps a date string ("yyyy-MM-dd") to the total number of focus minutes recorded on that day.
 */
class SessionsRepository(private val context: Context) {

    private val gson = Gson()
    private val mapType = object : TypeToken<MutableMap<String, Int>>() {}.type
    private val DAILY_MINUTES_KEY = stringPreferencesKey("daily_minutes_json")

    /**
     * Flow emitting the current daily minutes map. Consumers can use this to compute
     * statistics such as totals for today, this week, this month, and to build heatmaps.
     */
    val dailyMinutesFlow: Flow<Map<LocalDate, Int>> = context.sessionDataStore.data
        .map { prefs ->
            val json = prefs[DAILY_MINUTES_KEY] ?: "{}"
            val map: MutableMap<String, Int> = gson.fromJson(json, mapType) ?: mutableMapOf()
            map.mapKeys { LocalDate.parse(it.key) }
        }

    /**
     * Records a completed session by incrementing the total minutes for the day on which
     * the session started. Sessions that span multiple days are attributed entirely to
     * the start day, which is reasonable for Pomodoro-length sessions.
     *
     * @param startTime epoch milliseconds when the session began
     * @param endTime epoch milliseconds when the session ended
     */
    suspend fun recordSession(startTime: Long, endTime: Long) {
        val zone = ZoneId.systemDefault()
        val startDate = Instant.ofEpochMilli(startTime).atZone(zone).toLocalDate()
        val minutes = java.time.temporal.ChronoUnit.MINUTES.between(
            Instant.ofEpochMilli(startTime), Instant.ofEpochMilli(endTime)
        ).toInt().coerceAtLeast(0)
        val dateKey = startDate.toString() // ISO-8601 yyyy-MM-dd

        context.sessionDataStore.edit { prefs ->
            val json = prefs[DAILY_MINUTES_KEY] ?: "{}"
            val map: MutableMap<String, Int> = gson.fromJson(json, mapType) ?: mutableMapOf()
            val current = map[dateKey] ?: 0
            map[dateKey] = current + minutes
            prefs[DAILY_MINUTES_KEY] = gson.toJson(map)
        }
    }
}